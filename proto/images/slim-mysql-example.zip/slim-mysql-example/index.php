<?php
//slim framework example from http://scottnelle.com/
require 'Slim/Slim.php';
\Slim\Slim::registerAutoloader();
$app = new \Slim\Slim();

// set up a route to handle requests to the root of the application
$app->get('/', function () use ($app) {
	// include out mysql connection code and make the connection
	require_once 'lib/mysql.php';
	$db = connect_db();

	// query the database
	$rs = $db->query( 'SELECT id, name, job FROM friends;' );

	// convert the record set into an associative array so we can work with it easily
	$data = $rs->fetch_all(MYSQLI_ASSOC);

	// render a the friends.php template, including a page title variable and the data from the database
	$app->render('friends.php', array(
			'page_title' => "Your Friends",
			'data' => $data
		)
	);
});

// run the application
$app->run();